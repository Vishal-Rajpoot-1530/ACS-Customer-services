import React, { ReactNode, useEffect, useMemo, useState } from 'react';
import {
    ChevronDown,
    ChevronRight,
    File,
    Folder,
    FolderPlus,
    MoreVertical,
    Pencil,
    Plus,
    Trash2,
} from 'lucide-react';
import { ImportedDocument } from '../types';

export type ExplorerFolder = {
    id: string;
    name: string;
    parentId: string | null;
};

interface FileExplorerSidebarProps {
    storageKey: string;
    documents: ImportedDocument[];
    selectedFolderId: string | null;
    onFolderChange: (folderId: string | null) => void;
    role: 'user' | 'admin';
    onAssignmentsChange?: (assignments: Record<string, string>) => void;
    externalAssignments?: Record<string, string>;
    sidebarSummary?: ReactNode;
}

const ROOT_FOLDER_ID = 'root';

const readFolders = (storageKey: string): ExplorerFolder[] => {
    try {
        const saved = JSON.parse(localStorage.getItem(storageKey) || '[]');
        return Array.isArray(saved) ? saved : [];
    } catch {
        return [];
    }
};

const readAssignments = (storageKey: string): Record<string, string> => {
    try {
        const saved = JSON.parse(localStorage.getItem(storageKey) || '{}');
        return saved && typeof saved === 'object' ? saved : {};
    } catch {
        return {};
    }
};

export const FileExplorerSidebar: React.FC<FileExplorerSidebarProps> = ({
    storageKey,
    documents,
    selectedFolderId,
    onFolderChange,
    role,
    onAssignmentsChange,
    externalAssignments,
    sidebarSummary,
}) => {
    const folderStorageKey = `${storageKey}:folders`;
    const assignmentStorageKey = `${storageKey}:assignments`;
    const [folders, setFolders] = useState<ExplorerFolder[]>(() => readFolders(folderStorageKey));
    const [assignments, setAssignments] = useState<Record<string, string>>(() => readAssignments(assignmentStorageKey));
    const [expanded, setExpanded] = useState<Set<string>>(new Set([ROOT_FOLDER_ID]));
    const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
    const [editingName, setEditingName] = useState('');
    const [menuFolderId, setMenuFolderId] = useState<string | null>(null);
    const [folderDialog, setFolderDialog] = useState<{ mode: 'create' | 'rename'; folderId?: string; parentId: string | null } | null>(null);
    const [folderDialogName, setFolderDialogName] = useState('');
    const [deleteFolderId, setDeleteFolderId] = useState<string | null>(null);
    const [explorerNotice, setExplorerNotice] = useState<string | null>(null);

    useEffect(() => {
        if (externalAssignments) setAssignments(externalAssignments);
    }, [externalAssignments]);

    useEffect(() => {
        localStorage.setItem(folderStorageKey, JSON.stringify(folders));
    }, [folderStorageKey, folders]);

    useEffect(() => {
        localStorage.setItem(assignmentStorageKey, JSON.stringify(assignments));
        onAssignmentsChange?.(assignments);
    }, [assignmentStorageKey, assignments, onAssignmentsChange]);

    const folderCounts = useMemo(() => {
        const counts: Record<string, number> = { [ROOT_FOLDER_ID]: 0 };
        documents.forEach((document) => {
            const folderId = assignments[document.id] || ROOT_FOLDER_ID;
            counts[folderId] = (counts[folderId] || 0) + 1;
        });
        return counts;
    }, [assignments, documents]);

    const childrenOf = (parentId: string | null) => folders.filter((folder) => folder.parentId === parentId);
    const selectedFolder = selectedFolderId ? folders.find((folder) => folder.id === selectedFolderId) : null;

    const toggleExpanded = (folderId: string) => {
        setExpanded((current) => {
            const next = new Set(current);
            if (next.has(folderId)) next.delete(folderId);
            else next.add(folderId);
            return next;
        });
    };

    const createFolder = (parentId: string | null) => {
        setFolderDialog({ mode: 'create', parentId });
        setFolderDialogName('');
    };

    const saveFolderDialog = () => {
        const name = folderDialogName.trim();
        if (!name) {
            setExplorerNotice('Enter a folder name to continue.');
            return;
        }

        if (folderDialog?.mode === 'rename' && folderDialog.folderId) {
            setFolders((current) => current.map((folder) => (
                folder.id === folderDialog.folderId ? { ...folder, name } : folder
            )));
            setFolderDialog(null);
            setFolderDialogName('');
            return;
        }

        const folder = { id: `folder-${Date.now()}`, name, parentId: folderDialog?.parentId || null };
        setFolders((current) => [...current, folder]);
        setExpanded((current) => new Set(current).add(folder.parentId || ROOT_FOLDER_ID));
        onFolderChange(folder.id);
        setFolderDialog(null);
        setFolderDialogName('');
    };

    const startRename = (folder: ExplorerFolder) => {
        setFolderDialog({ mode: 'rename', folderId: folder.id, parentId: folder.parentId });
        setFolderDialogName(folder.name);
        setMenuFolderId(null);
    };

    const finishRename = () => {
        if (!editingFolderId || !editingName.trim()) {
            setEditingFolderId(null);
            return;
        }
        setFolders((current) => current.map((folder) => (
            folder.id === editingFolderId ? { ...folder, name: editingName.trim() } : folder
        )));
        setEditingFolderId(null);
    };

    const deleteFolder = (folderId: string) => {
        const hasChildren = folders.some((folder) => folder.parentId === folderId);
        if (hasChildren) {
            setExplorerNotice('Move or delete subfolders before deleting this folder.');
            return;
        }
        setDeleteFolderId(folderId);
    };

    const confirmDeleteFolder = () => {
        if (!deleteFolderId) return;
        const folderId = deleteFolderId;
        setFolders((current) => current.filter((folder) => folder.id !== folderId));
        setAssignments((current) => {
            const next = { ...current };
            Object.keys(next).forEach((documentId) => {
                if (next[documentId] === folderId) delete next[documentId];
            });
            return next;
        });
        if (selectedFolderId === folderId) onFolderChange(null);
        setMenuFolderId(null);
        setDeleteFolderId(null);
    };

    const moveDocumentToFolder = (event: React.DragEvent, folderId: string | null) => {
        event.preventDefault();
        const documentId = event.dataTransfer.getData('text/document-id');
        if (documentId) setAssignments((current) => ({ ...current, [documentId]: folderId || ROOT_FOLDER_ID }));
    };

    const renderFolder = (folder: ExplorerFolder, depth: number): React.ReactNode => {
        const children = childrenOf(folder.id);
        const isExpanded = expanded.has(folder.id);
        const isSelected = selectedFolderId === folder.id;

        return (
            <React.Fragment key={folder.id}>
                <div
                    className={`group relative flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs ${isSelected ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-50'}`}
                    style={{ paddingLeft: `${8 + depth * 14}px` }}
                    onDragOver={(event) => event.preventDefault()}
                    onDrop={(event) => moveDocumentToFolder(event, folder.id)}
                >
                    <button type="button" onClick={() => toggleExpanded(folder.id)} className="p-0.5" aria-label={`${isExpanded ? 'Collapse' : 'Expand'} ${folder.name}`}>
                        {children.length > 0 ? (isExpanded ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />) : <span className="inline-block w-3.5" />}
                    </button>
                    <button type="button" onClick={() => onFolderChange(folder.id)} className="flex min-w-0 flex-1 items-center gap-2 text-left">
                        <Folder className={`h-4 w-4 shrink-0 ${isSelected ? 'text-blue-600' : 'text-amber-500'}`} />
                        {editingFolderId === folder.id ? (
                            <input autoFocus value={editingName} onChange={(event) => setEditingName(event.target.value)} onBlur={finishRename} onKeyDown={(event) => { if (event.key === 'Enter') finishRename(); if (event.key === 'Escape') setEditingFolderId(null); }} className="min-w-0 w-full rounded border border-blue-300 px-1 text-xs" />
                        ) : <span className="truncate">{folder.name}</span>}
                        <span className="ml-auto text-[10px] text-slate-400">{folderCounts[folder.id] || 0}</span>
                    </button>
                    <button type="button" onClick={() => setMenuFolderId(menuFolderId === folder.id ? null : folder.id)} className="invisible p-1 group-hover:visible" aria-label={`Actions for ${folder.name}`}>
                        <MoreVertical className="h-3.5 w-3.5" />
                    </button>
                    {menuFolderId === folder.id && (
                        <div className="absolute ml-28 mt-20 z-20 w-32 rounded-lg border border-slate-200 bg-white p-1 shadow-lg">
                            <button type="button" onClick={() => startRename(folder)} className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-xs hover:bg-slate-50"><Pencil className="h-3.5 w-3.5" />Rename</button>
                            <button type="button" onClick={() => createFolder(folder.id)} className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-xs hover:bg-slate-50"><FolderPlus className="h-3.5 w-3.5" />New folder</button>
                            <button type="button" onClick={() => deleteFolder(folder.id)} className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-xs text-red-600 hover:bg-red-50"><Trash2 className="h-3.5 w-3.5" />Delete</button>
                        </div>
                    )}
                </div>
                {isExpanded && children.map((child) => renderFolder(child, depth + 1))}
            </React.Fragment>
        );
    };

    return (
        <aside className="w-full shrink-0 rounded-2xl border border-slate-200 bg-white p-3 shadow-xs lg:w-64 lg:self-start lg:sticky lg:top-5">
            <div className="mb-2 flex items-center justify-between px-2">
                <div className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-slate-700"><Folder className="h-4 w-4 text-blue-600" />Explorer</div>
                <button type="button" onClick={() => createFolder(null)} className="rounded-lg p-1.5 text-blue-600 hover:bg-blue-50" title="Create folder" aria-label="Create folder"><Plus className="h-4 w-4" /></button>
            </div>
            <div className="mb-2 border-b border-slate-100 pb-2 text-[10px] text-slate-400">
                {role === 'admin' ? 'Admin workspace · manage visible files' : 'Personal workspace · your files only'}
            </div>
            <div className="mb-2 flex items-center gap-1 px-2 text-[10px] text-slate-400" aria-label="Current folder">
                <span>Location:</span><span className="truncate font-semibold text-slate-600">{selectedFolder?.name || 'All files'}</span>
            </div>
            <div
                className={`flex items-center gap-2 rounded-lg px-2 py-2 text-xs ${selectedFolderId === null ? 'bg-blue-50 font-bold text-blue-700' : 'text-slate-600 hover:bg-slate-50'}`}
                onDragOver={(event) => event.preventDefault()}
                onDrop={(event) => moveDocumentToFolder(event, null)}
            >
                <button type="button" onClick={() => onFolderChange(null)} className="flex min-w-0 flex-1 items-center gap-2 text-left"><Folder className="h-4 w-4 text-blue-500" /><span>All files</span><span className="ml-auto text-[10px] text-slate-400">{documents.length}</span></button>
                <button type="button" onClick={() => createFolder(null)} className="p-1 text-slate-400 hover:text-blue-600" title="Create folder in root" aria-label="Create folder in root"><FolderPlus className="h-3.5 w-3.5" /></button>
            </div>
            <div className="mt-1">{childrenOf(null).map((folder) => renderFolder(folder, 0))}</div>
            {documents.length > 0 && (
                <div className="mt-3 flex items-center gap-2 border-t border-slate-100 px-2 pt-3 text-[10px] text-slate-400"><File className="h-3.5 w-3.5" />{documents.length} total files</div>
            )}
            <div className="mt-3 rounded-lg bg-slate-50 px-2.5 py-2 text-[10px] leading-relaxed text-slate-500">
                <strong className="block text-slate-700">Explorer rules</strong>
                <span>Upload to the selected folder. Drag files to move them. Create, rename, and delete empty folders.</span>
            </div>
            {sidebarSummary && <div className="mt-4 border-t border-slate-100 pt-3">{sidebarSummary}</div>}
            {explorerNotice && (
                <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800" role="status">
                    <div className="flex items-start justify-between gap-2"><span>{explorerNotice}</span><button type="button" onClick={() => setExplorerNotice(null)} className="font-bold" aria-label="Dismiss notice">×</button></div>
                </div>
            )}
            {(folderDialog || deleteFolderId) && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4" onClick={() => { setFolderDialog(null); setDeleteFolderId(null); }}>
                    <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-2xl" onClick={(event) => event.stopPropagation()}>
                        {folderDialog ? (
                            <>
                                <h2 className="text-base font-extrabold text-slate-900">{folderDialog.mode === 'create' ? 'Create folder' : 'Rename folder'}</h2>
                                <p className="mt-1 text-xs text-slate-500">Choose a clear name for this directory.</p>
                                <input autoFocus value={folderDialogName} onChange={(event) => { setFolderDialogName(event.target.value); setExplorerNotice(null); }} onKeyDown={(event) => { if (event.key === 'Enter') saveFolderDialog(); if (event.key === 'Escape') setFolderDialog(null); }} placeholder="Folder name" className="mt-4 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20" />
                                {explorerNotice && <p className="mt-2 text-xs font-semibold text-red-600">{explorerNotice}</p>}
                                <div className="mt-4 flex justify-end gap-2"><button type="button" onClick={() => setFolderDialog(null)} className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600">Cancel</button><button type="button" onClick={saveFolderDialog} className="rounded-lg bg-blue-600 px-3 py-2 text-xs font-bold text-white">Save</button></div>
                            </>
                        ) : (
                            <>
                                <h2 className="text-base font-extrabold text-slate-900">Delete folder?</h2>
                                <p className="mt-1 text-xs text-slate-500">Files in this folder will return to All files.</p>
                                <div className="mt-4 flex justify-end gap-2"><button type="button" onClick={() => setDeleteFolderId(null)} className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-bold text-slate-600">Cancel</button><button type="button" onClick={confirmDeleteFolder} className="rounded-lg bg-red-600 px-3 py-2 text-xs font-bold text-white">Delete folder</button></div>
                            </>
                        )}
                    </div>
                </div>
            )}
        </aside>
    );
};

export const getExplorerAssignments = (storageKey: string): Record<string, string> => readAssignments(`${storageKey}:assignments`);

export const getExplorerFolders = (storageKey: string): ExplorerFolder[] => readFolders(`${storageKey}:folders`);

export { ROOT_FOLDER_ID };
