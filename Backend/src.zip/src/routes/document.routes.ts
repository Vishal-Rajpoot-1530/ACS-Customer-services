import { Router } from 'express';
import { documentController } from '../controllers/document.controller';
import { authenticate, optionalAuthenticate } from '../middlewares/auth.middleware';
import { uploadDocuments } from '../middlewares/upload.middleware';
import { validateRequest } from '../middlewares/validate.middleware';
import {
  documentIdParamSchema,
  listDocumentsQuerySchema,
} from '../validators/document.validator';
import { uploadLimiter } from '../middlewares/rateLimiter.middleware';
import { authorize } from '../middlewares/role.middleware';
import { UserRoles } from '../constants/roles.constant';

const router = Router();

// Upload document (supports authenticated user or guest import)
router.post(
  '/',
  uploadLimiter,
  optionalAuthenticate,
  uploadDocuments,
  documentController.upload.bind(documentController)
);

// List user documents
router.get(
  '/',
  authenticate,
  validateRequest(listDocumentsQuerySchema),
  documentController.list.bind(documentController)
);

// Get single document metadata
router.get(
  '/:id',
  authenticate,
  validateRequest(documentIdParamSchema),
  documentController.getById.bind(documentController)
);

// Get temporary presigned download/view URL
router.get(
  '/:id/download',
  authenticate,
  validateRequest(documentIdParamSchema),
  documentController.getDownloadUrl.bind(documentController)
);

// Delete document
router.delete(
  '/:id',
  authenticate,
  authorize(UserRoles.ADMIN),
  validateRequest(documentIdParamSchema),
  documentController.delete.bind(documentController)
);

export default router;
