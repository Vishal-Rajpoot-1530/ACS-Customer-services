import mysql, { Pool } from 'mysql2/promise';
import { env } from './env.config';
import { logger } from './logger.config';

export const pool: Pool = mysql.createPool({
  host: env.MYSQL_HOST,
  port: env.MYSQL_PORT,
  user: env.MYSQL_USER,
  password: env.MYSQL_PASSWORD,
  database: env.MYSQL_DATABASE,
  connectionLimit: env.MYSQL_CONNECTION_LIMIT,
  waitForConnections: true,
  decimalNumbers: true,
});

export const connectDatabase = async (): Promise<void> => {
  try {
    await pool.query('SELECT 1');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id CHAR(36) PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NULL,
        display_name VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'USER',
        photo_url TEXT NULL,
        is_email_verified BOOLEAN NOT NULL DEFAULT FALSE,
        google_id VARCHAR(255) NULL UNIQUE,
        last_login DATETIME NOT NULL,
        password_reset_token_hash VARCHAR(255) NULL,
        password_reset_expires_at DATETIME NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        INDEX idx_users_role (role),
        INDEX idx_users_created_at (created_at)
      ) ENGINE=InnoDB;
    `);
    await pool.query(`
      CREATE TABLE IF NOT EXISTS documents (
        id CHAR(36) PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        stored_name VARCHAR(255) NOT NULL,
        s3_bucket VARCHAR(255) NOT NULL,
        s3_key VARCHAR(500) NOT NULL UNIQUE,
        mime_type VARCHAR(255) NOT NULL,
        extension VARCHAR(32) NOT NULL,
        size BIGINT NOT NULL,
        status VARCHAR(32) NOT NULL DEFAULT 'ready',
        category VARCHAR(255) NOT NULL DEFAULT 'Print Job',
        notes TEXT NULL,
        imported_by VARCHAR(255) NOT NULL,
        user_email VARCHAR(255) NOT NULL,
        imported_at VARCHAR(64) NOT NULL,
        print_options JSON NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        INDEX idx_documents_user_created (user_id, created_at),
        INDEX idx_documents_status_created (status, created_at),
        INDEX idx_documents_category_created (category, created_at)
      ) ENGINE=InnoDB;
    `);
    await pool.query(`
      CREATE TABLE IF NOT EXISTS refresh_tokens (
        id CHAR(36) PRIMARY KEY,
        user_id CHAR(36) NOT NULL,
        token_hash VARCHAR(255) NOT NULL UNIQUE,
        expires_at DATETIME NOT NULL,
        revoked_at DATETIME NULL,
        replaced_by_token_hash VARCHAR(255) NULL,
        ip_address VARCHAR(255) NULL,
        user_agent TEXT NULL,
        created_at DATETIME NOT NULL,
        INDEX idx_refresh_user (user_id),
        INDEX idx_refresh_expires (expires_at)
      ) ENGINE=InnoDB;
    `);
    await pool.query(`
      CREATE TABLE IF NOT EXISTS contact_inquiries (
        id CHAR(36) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        mobile VARCHAR(64) NOT NULL,
        email VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        status VARCHAR(32) NOT NULL DEFAULT 'new',
        created_at DATETIME NOT NULL,
        INDEX idx_inquiries_created (created_at)
      ) ENGINE=InnoDB;
    `);
    logger.info(`✅ MySQL connected: ${env.MYSQL_HOST}:${env.MYSQL_PORT}/${env.MYSQL_DATABASE}`);
  } catch (error: any) {
    logger.error(`❌ Failed to connect to MySQL: ${error.message}`);
    logger.warn('⚠️ The API server is running, but database operations will fail until MySQL is started.');
  }
};

export const disconnectDatabase = async (): Promise<void> => {
  try {
    await pool.end();
    logger.info('MySQL connection closed.');
  } catch (error) {
    logger.error('Error during MySQL disconnection:', error);
  }
};

export const isDatabaseHealthy = async (): Promise<boolean> => {
  try {
    await pool.query('SELECT 1');
    return true;
  } catch {
    return false;
  }
};
