import { userRepository } from '../repositories/user.repository';
import { AppError } from '../utils/appError';
import { HttpStatusCodes } from '../constants/httpStatusCodes.constant';
import { AuthenticatedUserResponse } from '../types/auth.types';
import { documentRepository } from '../repositories/document.repository';
import { s3Service } from './s3.service';
import { userId as getUserId } from '../models/user.model';
import { documentId } from '../models/document.model';

export class UserService {
  async listUsers(): Promise<AuthenticatedUserResponse[]> {
    const users = await userRepository.findAll();
    return users.map((user) => ({
      id: getUserId(user),
      email: user.email,
      displayName: user.displayName,
      role: user.role,
      photoURL: user.photoURL,
      isEmailVerified: user.isEmailVerified,
      lastLogin: user.lastLogin,
    }));
  }

  async deleteUser(userId: string, requestingUserId: string): Promise<void> {
    if (userId === requestingUserId) {
      throw new AppError('Administrators cannot delete their own account', HttpStatusCodes.BAD_REQUEST, 'SELF_DELETE_FORBIDDEN');
    }

    const user = await userRepository.findById(userId);
    if (!user) {
      throw new AppError('User not found', HttpStatusCodes.NOT_FOUND, 'USER_NOT_FOUND');
    }
    if (user.role !== 'USER') {
      throw new AppError('Only customer accounts can be deleted here', HttpStatusCodes.FORBIDDEN, 'ADMIN_DELETE_FORBIDDEN');
    }

    const documents = await documentRepository.findByOwnerId(userId);
    await Promise.all(documents.map(async (document) => {
      try {
        await s3Service.deleteFile(document.s3Key);
      } catch {
        // The database record is still removed when the storage object is missing.
      }
      await documentRepository.deleteById(documentId(document));
    }));

    await userRepository.deleteById(userId);
  }

  async updateProfile(
    userId: string,
    data: { displayName?: string; photoURL?: string }
  ): Promise<AuthenticatedUserResponse> {
    const user = await userRepository.findById(userId);
    if (!user) {
      throw new AppError('User not found', HttpStatusCodes.NOT_FOUND, 'USER_NOT_FOUND');
    }

    if (data.displayName) user.displayName = data.displayName.trim();
    if (data.photoURL !== undefined) user.photoURL = data.photoURL;

    await userRepository.updateById(getUserId(user), {
      displayName: user.displayName,
      photoURL: user.photoURL,
    });

    return {
      id: getUserId(user),
      email: user.email,
      displayName: user.displayName,
      role: user.role,
      photoURL: user.photoURL,
      isEmailVerified: user.isEmailVerified,
      lastLogin: user.lastLogin,
    };
  }
}

export const userService = new UserService();
