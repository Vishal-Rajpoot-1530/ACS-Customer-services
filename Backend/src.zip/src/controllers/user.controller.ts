import { NextFunction, Request, Response } from 'express';
import { userService } from '../services/user.service';
import { sendSuccess } from '../utils/response';

export class UserController {
  async updateProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const userId = req.user!.userId;
      const { displayName, photoURL } = req.body;

      const updatedUser = await userService.updateProfile(userId, { displayName, photoURL });

      sendSuccess(res, 'Profile updated successfully', { user: updatedUser });
    } catch (error) {
      next(error);
    }
  }
}

export const userController = new UserController();
